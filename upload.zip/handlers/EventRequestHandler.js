var rp = require('request-promise');

exports.EventRequestHandler = {
  canHandle: function(handlerInput){
    return handlerInput.requestEnvelope.isMatch('EventRequest');
  },
  handle: async function(handlerInput){
    // TODO Userを作成する。

    const uri = "http://" + process.env["serverIP"] + "/api/v1/cek/user_create";
    var options = {
      method: 'POST',
      uri: uri,
      form: {
        userId: handlerInput.requestEnvelope.session.user.userId,
      },
    }

    rp(options).then( data => {
      resolve( JSON.parse(data) );
    }).catch( err => {
      resolve(err);
    })

    return handlerInput.responseBuilder
      .speak("スキル登録")
      .getResponse();

  }
}
