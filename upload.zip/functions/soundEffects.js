exports.soundEffects = {
  radio: "https://s3-ap-northeast-1.amazonaws.com/utaite-sound-effects/clova/radio.mp3",
  liked: "https://s3-ap-northeast-1.amazonaws.com/utaite-sound-effects/clova/liked.mp3",
}
